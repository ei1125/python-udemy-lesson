from distutils.core import setup

setup( 
    name='python_programming',
    version='1.0.0',
    packages=['lesson68_package', 'lesson68_package.talk', 'lesson68_package.tools'],
    url='https://sakaijunsoccer.appspot.com',
    license='Free',
    author='morishita',
    author_email='',
    description='Sample package'
)