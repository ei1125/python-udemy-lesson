from lesson68_package.tools import utils

def sing():
    return 'ga;wrina;sdfa;owiegna'

def cry():
    return utils.say_twice('ajkba;jweng;a')